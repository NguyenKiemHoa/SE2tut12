package jersey.service;

import java.util.ArrayList;
import java.util.List;

import jersey.model.Teacher;

public class TeacherService {
	public List<Teacher> getAllTeachers(){
		List<Teacher> list = new ArrayList<>();
		list.add(new Teacher(1, "Teacher 1", "0123456789"));
		list.add(new Teacher(2, "Teacher 2", "9876543210"));
		
		return list;
	}
}
