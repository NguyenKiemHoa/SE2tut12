package jersey.service;

import java.util.ArrayList;
import java.util.List;

import jersey.model.Course;

public class CourseService {
	public List<Course> getAllCourses(){
		List<Course> list = new ArrayList<>();
		list.add(new Course(1, "Course1"));
		list.add(new Course(2, "Course2"));
		
		return list;
	}
}
