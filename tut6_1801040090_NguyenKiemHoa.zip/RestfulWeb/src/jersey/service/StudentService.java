package jersey.service;

import java.util.ArrayList;
import java.util.List;

import jersey.model.Student;

public class StudentService {
	public List<Student> getAllStudents(){
		Student s1 = new Student(1,"Nguyen Van A", "1111111");
		Student s2 = new Student(2,"Nguyen Van B", "2222222");
		List<Student> list = new ArrayList<Student>();
		list.add(s1);
		list.add(s2);
		return list;
	}
}
