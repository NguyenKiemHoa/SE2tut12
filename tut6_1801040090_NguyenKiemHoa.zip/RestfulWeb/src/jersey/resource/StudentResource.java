package jersey.resource;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import jersey.service.CourseService;
import jersey.service.StudentService;
import jersey.service.TeacherService;

@Path("/student")
public class StudentResource {
	StudentService studentService = new StudentService();
	TeacherService teacherService = new TeacherService();
	CourseService courseService = new CourseService();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List getStudent(){
		List all = new ArrayList<>();
		all.add(studentService.getAllStudents());
		all.add(teacherService.getAllTeachers());
		all.add(courseService.getAllCourses());
		return all;
	}
	
}
