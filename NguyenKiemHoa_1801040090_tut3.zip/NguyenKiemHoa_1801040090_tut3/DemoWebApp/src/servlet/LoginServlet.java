package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		if (username.equals("admin") && password.equals("123456")) {
			pw.println(
					"<html>\n" + 
					"<body>" + 
					"<h2> Welcome, " + username + " !\n" + 
					"</body>" + 
					"</html>");
		} else {
			pw.println("<html>\n" + 
					"<body>" + 
					"<h2> Invalid username or password!\n" + 
					"</body>" + 
					"</html>");
		}
		pw.close();
	}
}
