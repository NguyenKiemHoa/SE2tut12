package to_dos.abstract_factory;

/* Create the AbstractFactoryTest class which uses the FactoryProducer 
 * to get AbstractFactory in order to get factories 
 * of concrete classes by passing an information such as type.
 */

public class AbstractFactoryTest {
	//TO-DO: Implement the main() method for testing purpose
	public static void main(String[] args) {
		// get shape factory
		ShapeFactory sf = new ShapeFactory();
		// get an object of Shape Rectangle
		Shape rec = sf.getShape("Rectangle");
		// call draw method of Shape Rectangle
		rec.draw();
		// get an object of Shape Square
		Shape sq = sf.getShape("Square");
		// call draw method of Shape Square
		sq.draw();
		// get shape factory
		RoundedShapeFactory rsf = new RoundedShapeFactory();
		// get an object of Shape Rectangle
		Shape rrec = rsf.getShape("Rectangle");
		// call draw method of Shape Rectangle
		rrec.draw();
		// get an object of Shape Square
		Shape rsq = rsf.getShape("Square");
		// call draw method of Shape Square
		rsq.draw();
	}
}