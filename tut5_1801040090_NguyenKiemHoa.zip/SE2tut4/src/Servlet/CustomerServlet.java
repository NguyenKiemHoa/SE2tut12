package Servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.CustomerDAO;
import Model.Customer;

import DAO.ItemDAO;
import Model.Item;

import DAO.BuyDAO;
import Model.Buy;

/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private CustomerDAO customerDAO;
    private ItemDAO itemDAO;
    private BuyDAO buyDAO;
	
    public void init() {
    	customerDAO = new CustomerDAO();
    	itemDAO = new ItemDAO();
    	buyDAO = new BuyDAO();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		String path = request.getServletPath();
		try {
			switch(path) {
				case "/new":
					showNewForm(request, response);
					break;
				case "/insert":
					insertCustomer(request, response);
					break;
				case "/edit":
					showEditForm(request, response);
					break;
				case "/update":
					updateCustomer(request, response);
					break;
				case "/delete":
					deleteCustomer(request, response);
					break;
				default:
					listCustomer(request, response);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private void listCustomer(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException{
		List<Customer> listCustomer = customerDAO.selectAllCustomers();
		List<Item> listItem = itemDAO.selectAllItems();
		List<Buy> listBuy = buyDAO.selectAllBuys();
		request.setAttribute("listCustomer", listCustomer);
		request.setAttribute("listItem", listItem);
		request.setAttribute("listBuy", listBuy);
		RequestDispatcher dispatcher = request.getRequestDispatcher("customer-list.jsp");
		dispatcher.forward(request, response);
	}
	
	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException{
		RequestDispatcher dispatcher = request.getRequestDispatcher("add-customer.jsp");
		dispatcher.forward(request, response);
	}
	
	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException{
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		int id = Integer.parseInt(request.getParameter("id"));
		Customer cus = CustomerDAO.selectCustomer(id);
		request.setAttribute("cus", cus);
		RequestDispatcher dispatcher = request.getRequestDispatcher("edit-customer.jsp");
		dispatcher.forward(request, response);
	}
	
	private void insertCustomer(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException{
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		Customer newCus = new Customer(name,email);
		CustomerDAO.insertCustomer(newCus);
		response.sendRedirect("list");
	}
	
	private void updateCustomer(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException{
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		Customer editCus = new Customer(Integer.parseInt(id),name,email);
		CustomerDAO.updateCustomer(editCus);
		response.sendRedirect("list");
	}
	
	private void deleteCustomer(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException{
		String id = request.getParameter("id");
		CustomerDAO.deleteCustomer(Integer.parseInt(id));
		response.sendRedirect("list");
	}
	

}
