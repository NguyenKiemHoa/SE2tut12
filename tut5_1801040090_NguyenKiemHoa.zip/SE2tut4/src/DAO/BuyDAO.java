package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Connection.dbConnect;
import Model.Buy;

public class BuyDAO {

	public BuyDAO() {
		
	}
	
	public static List<Buy> selectAllBuys(){
		List<Buy> buy = new ArrayList<>();
		Connection connection = dbConnect.getConnection();
		String selectAll = "SELECT * FROM buy";
		try {
			PreparedStatement ps = connection.prepareStatement(selectAll);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				int id = rs.getInt(1);
				int customerId = rs.getInt(2);
				int itemId = rs.getInt(3);
				int amount = rs.getInt(4);
				buy.add(new Buy(id,customerId, itemId,amount));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return buy;
	}
}
