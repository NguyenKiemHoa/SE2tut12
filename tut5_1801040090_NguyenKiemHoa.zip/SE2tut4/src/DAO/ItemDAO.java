package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Connection.dbConnect;
import Model.Item;

public class ItemDAO {

	public ItemDAO() {
		
	}
	
	public static List<Item> selectAllItems(){
		List<Item> item = new ArrayList<>();
		Connection connection = dbConnect.getConnection();
		String selectAll = "SELECT * FROM item";
		try {
			PreparedStatement ps = connection.prepareStatement(selectAll);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int amount = rs.getInt(3);
				item.add(new Item(id,name,amount));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return item;
	}
}
