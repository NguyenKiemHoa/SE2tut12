package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Connection.dbConnect;
import Model.Customer;

public class CustomerDAO {
	
	private static Connection connection = dbConnect.getConnection();
	
	public CustomerDAO() {
		
	}
	
	public static List<Customer> selectAllCustomers(){
		List<Customer> cus = new ArrayList<>();
		
		String selectAll = "SELECT * FROM customer";
		try {
			PreparedStatement ps = connection.prepareStatement(selectAll);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String email = rs.getString(3);
				cus.add(new Customer(id,name,email));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cus;
	}
	
	public static Customer selectCustomer(int id) {
		Customer cus = null;
		String query = "SELECT * FROM customer WHERE customer_id=?";
		PreparedStatement ps;
		try {
			ps = connection.prepareStatement(query);
			ps.setInt(1,id);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				String name = rs.getString(2);
				String email = rs.getString(3);
				cus = new Customer(id,name,email);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cus;
	}
	
	public static boolean deleteCustomer(int id) {
		String query = "DELETE FROM Customer WHERE customer_id=?";
		boolean deleteCustomer = false;
		
		try {
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setInt(1, id);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		deleteCustomer = true;
		return deleteCustomer;
	}
	
	public static void insertCustomer(Customer cus) {
		String query = "INSERT INTO Customer(customer_name,customer_email) VALUES (?,?)";
		
		try {
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setString(1, cus.getName());
			ps.setString(2, cus.getEmail());
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static boolean updateCustomer(Customer cus) {
		String query = "UPDATE Customer SET customer_name=?, customer_email=? WHERE customer_id=?";
		boolean updateCustomer = false;
		
		try {
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setString(1, cus.getName());
			ps.setString(2, cus.getEmail());
			ps.setInt(3, cus.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		updateCustomer = true;
		return updateCustomer;
	}
}
