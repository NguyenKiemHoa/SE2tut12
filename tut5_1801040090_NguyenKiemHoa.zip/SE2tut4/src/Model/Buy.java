package Model;

public class Buy {
	protected int id;
	protected int customerId;
	protected int itemId;
	protected int amount;
	
	public Buy() {
		
	}
	
	public Buy(int customerId, int itemId, int amount) {
		this.customerId = customerId;
		this.itemId = itemId;
		this.amount = amount;
	}
	
	public Buy(int id, int customerId, int itemId, int amount) {
		this.id = id;
		this.customerId = customerId;
		this.itemId = itemId;
		this.amount = amount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
}
