package tut10.adapter;

import tut10.adapter.adapter.SquarePegAdapter;
import tut10.adapter.round.RoundHole;
import tut10.adapter.round.RoundPeg;
import tut10.adapter.square.SquarePeg;

/**
 * Somewhere in client code...
 */
public class Demo {
	public static void main(String[] args) {
		//TO-DO: Create 2 instances of RoundHole and RoundPeg with same radius
                RoundHole hole = new RoundHole(4);
                RoundPeg peg = new RoundPeg(4);
		//TO-DO: If RoundHole instance can "fits" with RoundPeg instance => show a message
                if(hole.fits(peg)){
                    System.out.println("Fit");
                }
		//TO-DO: Create 2 instances of SquarePeg with 2 different widths
                SquarePeg peg1 = new SquarePeg(2);
                SquarePeg peg2 = new SquarePeg(3);
		//Note: You can't make RoundHole instance "fit" with SquarePeg instance
		//Therefore, we need to use Adapter for solving the problem.
		
		//TO-DO: Create 2 corresponding instances of SquarePegAdapter  
		 SquarePegAdapter a1 = new SquarePegAdapter(peg1);
                 SquarePegAdapter a2 = new SquarePegAdapter(peg2);
		//TO-DO: If the RoundHole instance can "fits" with "small" RoundPegAdapter instance 
		//show a suitable message
                if(a1.getRadius() <= hole.getRadius()){
                    System.out.println("fit");
                }
		//TO-DO: If the RoundHole instance can not "fits" with "big" RoundPegAdapter instance 
		//show a suitable message
                else{
                    System.out.println("not fit");
                }
                if(a2.getRadius() <= hole.getRadius()){
                    System.out.println("fit");
                }else{
                    System.out.println("not fit");
                }
	}
}