package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Connection.dbConnect;
import Model.Customer;

public class CustomerDAO {
	
	public CustomerDAO() {
		
	}
	
	public static List<Customer> selectAllCustomers(){
		List<Customer> cus = new ArrayList<>();
		Connection connection = dbConnect.getConnection();
		String selectAll = "SELECT * FROM customer";
		try {
			PreparedStatement ps = connection.prepareStatement(selectAll);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String email = rs.getString(3);
				cus.add(new Customer(id,name,email));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cus;
	}
}
